package naoki.ble_myo.unused;

/**
 * Created by naoki on 15/04/16.
 */
public interface IGestureDetectAction {
    public void action(String Tag );
}
